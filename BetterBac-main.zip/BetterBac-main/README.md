<img src="https://i.ibb.co/yR8mYBk/Rounded-Corner-Image-July-30.png" />

Like ManageBac, but better.

BUILD FAST AND BREAK THINGS. This is your time.

Start off with only everything minus CAS, TOK, EE, etc. => which still allows u topivot to general and non-IB IF necessary. :)

WOOOO. Let's get it. Come on.

Made with ❤️ by Filippo Fonseca.
