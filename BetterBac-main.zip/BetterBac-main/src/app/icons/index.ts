export type IconProps = React.SVGAttributes<SVGElement>;
