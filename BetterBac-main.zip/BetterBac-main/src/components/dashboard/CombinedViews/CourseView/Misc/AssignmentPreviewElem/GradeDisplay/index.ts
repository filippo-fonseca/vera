export { default } from "./GradeDisplay";
