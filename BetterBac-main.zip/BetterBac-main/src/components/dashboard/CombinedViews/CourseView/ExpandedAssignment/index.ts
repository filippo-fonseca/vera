export { default } from "./ExpandedAssignment";
