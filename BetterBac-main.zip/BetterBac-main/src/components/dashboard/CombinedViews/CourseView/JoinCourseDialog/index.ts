export { default } from "./JoinCourseDialog";
