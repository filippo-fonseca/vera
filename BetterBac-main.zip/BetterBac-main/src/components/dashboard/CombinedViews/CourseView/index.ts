export { default } from "./CourseView";
