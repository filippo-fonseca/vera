export { default } from "./GradeBoundaries";
