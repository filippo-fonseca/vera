export { default } from "./NoCourses";
