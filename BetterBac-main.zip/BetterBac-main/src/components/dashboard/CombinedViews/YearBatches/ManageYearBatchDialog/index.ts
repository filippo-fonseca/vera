export { default } from "./ManageYearBatchElem";
