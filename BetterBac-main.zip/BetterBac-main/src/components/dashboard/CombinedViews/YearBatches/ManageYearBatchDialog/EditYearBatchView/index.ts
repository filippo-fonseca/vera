export { default } from "./EditYearBatchView";
