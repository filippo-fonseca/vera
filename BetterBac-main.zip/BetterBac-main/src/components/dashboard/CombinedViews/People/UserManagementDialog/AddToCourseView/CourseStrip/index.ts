export { default } from "./CourseStrip";
