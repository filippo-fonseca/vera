export { default } from "./SchoolHome";
