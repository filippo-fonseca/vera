export { default } from "./SchoolAdmins";
