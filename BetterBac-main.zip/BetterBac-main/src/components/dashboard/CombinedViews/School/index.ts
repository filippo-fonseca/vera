export { default } from "./School";
