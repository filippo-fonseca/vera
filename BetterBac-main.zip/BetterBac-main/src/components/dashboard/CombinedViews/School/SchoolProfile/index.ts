export { default } from "./SchoolProfile";
