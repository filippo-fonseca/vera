export { default } from "./SchoolSettings";
