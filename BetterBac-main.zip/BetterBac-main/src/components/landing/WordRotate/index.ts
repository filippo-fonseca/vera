export { default } from './WordRotate';
