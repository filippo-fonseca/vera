export { default } from './TypingAnimationText';
