export { default } from "./GeneralSpinnerLoader";
