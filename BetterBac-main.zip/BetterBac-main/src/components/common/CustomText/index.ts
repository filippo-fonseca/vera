export { default } from './CustomText';
