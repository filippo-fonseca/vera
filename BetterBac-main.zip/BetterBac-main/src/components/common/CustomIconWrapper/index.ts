export { default } from "./CustomIconWrapper";
