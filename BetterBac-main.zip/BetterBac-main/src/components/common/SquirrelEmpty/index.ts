export { default } from "./SquirrelEmpty";
