export { default } from "./ManagerialPageHeader";
